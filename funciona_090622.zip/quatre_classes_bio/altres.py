from posixpath import split


def intersecció(a,b): 
    for i in range(2): 
        intersecció_per_imprimir=[]
        for j in range(2):
            cromosoma_1 = a[j]
            cromosoma_2 = b[j] 
            for k in range(len(cromosoma_1)): 
                if cromosoma_1[k] == cromosoma_2[k]: 
                    intersecció_per_imprimir.append(cromosoma_1[k])
                else: 
                    intersecció_per_imprimir.append('-')
    
    cr_1, cr_2 = split_list(intersecció_per_imprimir)
    string_1 = "".join(cr_1)     
    string_2 =  "".join(cr_2)
    print(string_1)
    print(string_2)

def split_list(list):
    half = len(list)//2
    return list[:half], list[half:]


def print_set_ordenat(a): 
    for i in sorted(a): 
        print(i)

    