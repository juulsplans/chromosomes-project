#INICIALITZACIONS------------------------------------
from easyinput import read 
from parell_cromosomes import Parell_Cromosomes
from conjunt_individus import Conjunt_Individus 
from conjunt_trets import Conjunt_De_Trets
from individu import * 
import sys 
fitxer = "C:/Users/Júlia Plans Vilaseca/Desktop/PRIMER/SEGON_QUATRI/PA_2/segona_part/pràctica_bio/quatre_classes_bio/prova_1.inp"
with open(fitxer) as f: 
    instrucció = read(str,file=f)
    
    while instrucció != 'fi': 
        if instrucció == 'experiment': # passa el debugg 
            obj_cjt_individus = Conjunt_Individus()
            obj_cjt_trets = Conjunt_De_Trets()
            obj_pc = Parell_Cromosomes()
            obj_individu = Individu()

            n = read(int,file=f)
            m = read(int,file=f)
            print(instrucció,' ',n,' ',m,sep="")
            obj_individu.inicialitzador_trets_individus(n)
            obj_cjt_individus.llegir_individus(obj_pc,n,m,f)
            
#---------------------------------------------------------------------------------------------------
        elif instrucció == 'afegir': # NO RETORNA RES 
            tret = read(str,file=f)
            individu = read(int,file=f)
            print(instrucció,' ',tret, ' ', individu, sep="")
            obj_cjt_trets.afegir_tret(obj_individu,obj_pc,tret,individu) 
           
#---------------------------------------------------------------------------------------------------
        elif instrucció == 'treure_tret': # per si volem + nota 
            pass
        # AIXÒ NO ÉS DEL TERCER?
#---------------------------------------------------------------------------------------------------
        elif instrucció == 'consulta_tret': # ESTÀ BÉ 
            nom_tret = read(str,file=f)
            print(instrucció,' ',nom_tret,sep="")
            #obj_cjt_tret = Conjunt_De_Trets()
            obj_cjt_trets.consulta_tret(nom_tret)
        # s'introdueix el nom d'un tret 
            # si no existeix 
                # error 
            # s'escriu la combinació que fa que es manifesti aquest tret 
                # per ordre creixent d'identificador
#---------------------------------------------------------------------------------------------------        
        elif instrucció == 'consulta_individu': 
            id_individu = read(int,file=f)
            #print(id_individu)
            print(instrucció,' ',id_individu,sep="")
            #obj_consulta_ind = Individu()
            # imprimim el parell de cromosomes
            obj_individu.consulta_individu_print(obj_pc,id_individu)
            #obj_individu.identificador_individu(id_individu)
        # s'introdueix un nombre d'identificador 
        # s'escriu la info d'aquell identificador 
            # parell de cromosomes 
            # nom dels trets per ordre alfabètic 
        #consulta = parell_cromosomes() 
        #consulta.consulta_individu(m)
#---------------------------------------------------------------------------------------------------
        elif instrucció == 'distribució_tret': 
        # s'introdueix el nom d'un possible tret
        # si no existeix s'escriu error 
            # s'escriu el subarbre resultat en inordre 
            pass 
    
        instrucció = read(str, file = f)

        #print(instrucció)
        #print(obj_cjt_ind.nombre_cromosomes)
        #print(obj_cjt_ind.nombre_individus)
        #print(obj_cjt_ind.getter_cromosomes_cjt_ind())
        #print(obj_individu._trets_individus)
        #print(lst)
#MIRAR PERQUÈ NO SE'M GUARDEN LES COSES A LES CLASSES :)       
    print('fi')