import collections
import individu as IND
import parell_cromosomes as PC
import bintree_solució as BT
class Conjunt_De_Trets: 
    def __init__(self): 
        self.__diccionari = dict() 
        self.__set_individus = set()

    def intersecció_existent(self,tret): 
        return (self.__diccionari).get(tret)[0]
    
    def afegir_tret(self,obj_individu,obj_pc,tret,i): 
        if (self.__diccionari).get(tret) == None:
            individu = IND.Individu()
            patró_de_tret = individu.consulta_individu(obj_pc,i) 
            set_individus = set()
            set_individus.add(i)
            self.__diccionari[tret] = (patró_de_tret,set_individus)
              
        else: 
            tupla = (self.__diccionari).get(tret) 
            print(tupla[0], 'EEEEH')
            print(tupla[1], 'GUAAAAAAA')
            #print(tupla)
            if i in tupla[1]: #aquí abans hi havia individu i funcionava 
                print('error')
            else: 
                llista_mutable = list(tupla)
                llista_mutable[0] = obj_pc.intersecció(self,i,tret)
                print(llista_mutable[0])
                llista_mutable[1].add(i)
                tupla = tuple(llista_mutable)
                self.__diccionari[tret] = tupla 
        obj_individu.afegeix_tret_a_un_individu(i,tret)
        #no ens oblidem de posar-ho també a l'identificador de trets (conjunt de trets que té cada individu)
        #obj = IND.Individu()
        #obj.afegeix_tret_a_un_individu(individu,tret)
    
    def consulta_tret(self,tret): # AIXÒ VA 
        if (self.__diccionari).get(tret) == None: 
            print('error')
        else: 
            print(tret)
            itupla = self.__diccionari.get(tret)
            print(itupla, 'BOOOLA')
            print(itupla[0], 'HOOOOOOLA')
            intersecció_existent = itupla[0]
            
            #print(intersecció_existent)
            #print(intersecció_existent)
            for i in range (len(intersecció_existent)): 
                str = "".join(intersecció_existent[i])
                print(str) 
            individus = self.__diccionari.get(tret)[1]
            sorted_individus = sorted(individus)
            for i in sorted_individus: # PRINT DELS INDIVIDUS ENDREÇATS 
                print(i)
    
    def existeix_el_tret(self,tret): 
        return (self.__diccionari).get(tret) != None

def split_list(list):
    half = len(list)//2
    return list[:half], list[half:]

#COSES A MIRAR 
"""quan faig tots els gets faig: 
>>> a.get(a)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: unhashable type: 'dict'
>>> a.get('a')
30
>>> a.get(str(a))
>>> t = a.get(str(a))
>>> t
com puc fer que em surti bé??"""
            


