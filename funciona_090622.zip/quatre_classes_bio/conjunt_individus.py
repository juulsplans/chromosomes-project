from easyinput import read
from bintree_solució import BinTree 
import individu as IND
import parell_cromosomes as PDC
import conjunt_trets as CT
        
class Conjunt_Individus: 
    def __init__(self): # HI HA D'HAVER UNA N i no sabem perquè  
        self.__arbre = BinTree()
        self.__cromosomes_individus = [] 

    def llegeix_bintree_int(self,marca,fitxer): 
        x = read(int,file=fitxer) 
        if x != marca:
            l = self.llegeix_bintree_int(marca,fitxer)
            r = self.llegeix_bintree_int(marca,fitxer)
            return BinTree(x,l,r)
        else:
            return BinTree()
    
    def llegir_individus(self,obj_pc,n,m,f): 
        self.__arbre = self.llegeix_bintree_int(0,f)
        self.__cromosomes_individus = [[] for i in range(n)]
        obj_pc.lectura_cromosomes(n,m,f)
        #self.__cromosomes_individus = obj_pc.return_chro_information()
        for i in range(n): 
            ind = IND.Individu()
            ind.consulta_individu(obj_pc,i)
            self.__cromosomes_individus[i] = ind
        #print(self.__cromosomes_individus)
        
    def distribució_tret(self,tret):
        a = self.__arbre
        if a.get_left() == None and a.get_right() == None: 
            pass 
    






   
#a = conjunt_individus()
#a.llegeix_bintree_int('0 0')
#a.conjunt_individus()
#a = Conjunt_Individus()
#a.llegir_individus(5,8,'prova_parell_cromosomes.inp') #AQUÍ TENIM UN ERROR, PERÒ CREC QUE ESTÀ BEN IMPLEMENTAT AIXÍ QUE CHILL 
    
    
        

                
#hem de tenir en compte que tenim ara un arbre que està capgirat, llavors per establir relacions de parentiu .. ? 
#per girar-lo hem d'obtenir el postordre, sobre el qual establirem les relacions de parentiu 
#PSEUDOCODI: llegir l'arbre, fer el postordre, i establir relacions cada dos, el tercer és el seu pare 

#AQUÍ TAMBÉ HEM DE FER UN CONJUNT DELS INDIVIDUS QUE TENIM """