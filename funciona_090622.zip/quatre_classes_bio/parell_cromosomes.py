import conjunt_trets as CJT_T
from easyinput import read
class Parell_Cromosomes: 
    def __init__(self): 
        self.__cromosomes_individus = []
        self.__intersecció = []
        self.nombre_cromosomes = 0 
        self.nombre_individus = 0 
    
    def lectura_cromosomes(self,n,m,f): 
        self.nombre_cromosomes = m 
        self.nombre_individus = n 
        for i in range(n): 
            individu = list(f.readline().strip())
            a = individu[:m]
            b = individu[m:]
            tuple = (a,b)
            self.__cromosomes_individus.append(tuple)
        return self.__cromosomes_individus

    def return_chro_information(self): 
        return self.__cromosomes_individus

    def intersecció(self,cjt_t,individu,tret): 
        #patró_del_tret = CJT_T.Conjunt_De_Trets()
        intersecció_existent = cjt_t.intersecció_existent(tret)
        print(intersecció_existent, 'OOOOOOOOOU')
        intersecció_completa = []
        for i in range(2): 
            intersecció_per_imprimir=[]
            for j in range(2): 
                cromosoma_1 = intersecció_existent[j]
                print(cromosoma_1, 'A')
                cromosoma_2 = self.__cromosomes_individus[individu-1][j]
                print(cromosoma_2,'B')
                for k in range(len(cromosoma_1)):
                    for w in range(len(cromosoma_1[k])): 
                        if cromosoma_1[w] == cromosoma_2[w]: 
                            intersecció_per_imprimir.append(cromosoma_1[k][w])
                    else: 
                        intersecció_per_imprimir.append('-')
            intersecció_completa.append(intersecció_per_imprimir)
            #print(intersecció_per_imprimir)
        for i in range(len(intersecció_completa)): 
            str = ["".join(intersecció_completa[i])]
            print(str[:len(intersecció_completa)])
            print(str[len(intersecció_completa):]) 



    
    
    
        


