from easyinput import read
import conjunt_trets as CJT_T
import conjunt_individus as CJT_I
import individu as IND
import parell_cromosomes as PC 

class Individu: 
    
    def __init__(self): 
        self.__inst_PC = PC.Parell_Cromosomes()
        self.__trets_individus = [] # llista dels trets que té cada individu NECESSARI 
        self.__cromosomes_individus = []


    def consulta_individu(self,obj_pc,i): # NOMÉS S'HA DE SER UNA VEGADA
        #self.__cromosomes_individus = self.__inst_PC.lectura_cromosomes(n,m,f)ç
        self.__cromosomes_individus = obj_pc.return_chro_information()
        individu = self.__cromosomes_individus[i-1]
        return tuple([tuple(x) for x in individu]) 


    def consulta_individu_print(self,obj_pc,individu_inp): 
        individu = self.consulta_individu(obj_pc,individu_inp)  
        for i in individu: 
            print("".join(map(str, i)))
        if self.__trets_individus[individu_inp-1] != set(): 
            trets_ind = [] #s'hauria de polir d'alguna manera que no quedés tan cutre 
            for i in self.__trets_individus[individu_inp-1]: 
                trets_ind.append(i)                
            for i in sorted(trets_ind): 
                print(i)

    def inicialitzador_trets_individus(self,n): 
        self.__trets_individus = [set() for i in range(n)]
        return self.__trets_individus
    
    def identificador_individu(self,individu):
        trets_de_l_individu = self.__trets_individus[individu-1] # ens retorna els trets que té cada individu
        for i in sorted(trets_de_l_individu): 
            print(i)

    def individus_que_tenen_el_tret_print(self,tret): 
        llista_ind = []
        trets_de_l_individu = self.__trets_individus
        # he de recórrer una llista de conjunts els quals tindran noms dels trets, he de buscar el tret en qüestió en aquests i he d'imprimir els individus que el tinguin 
        for i in range(len(trets_de_l_individu)): 
            if tret in trets_de_l_individu[i]: 
                llista_ind.append(i)
        print(sorted(llista_ind))

    def afegeix_tret_a_un_individu(obj_individu,individu,tret):
        obj_individu.__trets_individus[individu-1].add(tret) #AQUÍ 
    

    
  

        