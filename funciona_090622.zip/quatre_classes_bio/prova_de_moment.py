#hem de llegir els cromosomes i posar-los en una tupla :) 
#exemple: (00010101,10101011)

#passos: 
        # llegir la primera línea
        # agafar l'element 2 de la llista, nombre de cromosomes 
        # llegir la segona línea i no fer res
        # llegir la tercera línea fins a la tercera+nombre de cromosomes 
        # per cada línea, hem de fer una llista, i separar-la en 8 i 8, posar-ho en una tuple.
from easyinput import read
class parell_cromosomes: 
    def __init__(self): 
        self._cromosomes_individus = []
        
    def lectura_cromosomes(self,m,n): 
        with open ("prova_parell_cromosomes.inp") as f: 
            first = f.readline().split()
            m = int(first[1]) #nombre d'individus 
            n = int(first[2]) #nombre de cromosomes 
            _cromosomes_individus = [] #tindrem una llista de tuples on cada tuple estarà vinculada a un individu 
            f.readline() #llegim la línea que ens dona el preordre que no n'hem de fer res 
            for i in range(m): 
                individu = list(f.readline().strip())
                #print(individu)
                a = individu[:n]
                b = individu[n:]
                tuple = (a,b)
                self._cromosomes_individus.append(tuple)
                _cromosomes_individus.append(tuple)
                
        #for i in self._cromosomes_individus: 
            #print(i) 
        #print(_cromosomes_individus)
        
    def consulta_individu(self,m): 
        self.lectura_cromosomes()
        individu = (self._cromosomes_individus)[m]
        for i in individu: 
            print("".join(map(str, i)))


a = parell_cromosomes()
a.consulta_individu(0)
    
